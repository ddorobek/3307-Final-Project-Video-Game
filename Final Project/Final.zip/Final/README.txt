For running the code on the pi:
- Use the following tutorial to install SFML on pi: https://www.sfml-dev.org/tutorials/2.5/start-linux.php
- Have all the .cpp and .h files and images in a directory on the pi and use the Makefile to compile them all
- Run the game by using ./game

For running on visual studio code please refer to:
- https://www.sfml-dev.org/tutorials/2.5/start-vc.php